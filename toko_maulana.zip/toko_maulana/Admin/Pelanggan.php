<div class="shadow p-3 mb-3 bg-purple rounded">
    <h5><b>Halaman Pelanggan</b></h5>
</div>

<?php

$Pelanggan = array();
$ambil = $Koneksi->query("SELECT * FROM Pelanggan");
while ($pecah = $ambil->fetch_assoc())
{
    $Pelanggan[] = $pecah;
}

?>

<div class="card shadow bg-purple">
   <div class="card-body">
    <table class="table table-bordered table-hover table-striped" id="Tables">
        <thead>
            <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Email</th>
            <th>Telepon</th>
            <th>Foto</th>
            <th>Opsi</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($Pelanggan as $Key => $value): ?>
            <tr>
               <td width="50"><?php echo $Key+1; ?></td>
               <td><?php echo $value['nama_Pelanggan']; ?></td>
               <td><?php echo $value['email_Pelanggan']; ?></td>
               <td><?php echo $value['telepon_Pelanggan']; ?></td>
               <td><?php echo $value['foto_Pelanggan']; ?></td>
               <td class="text-center" width="150">
               <a href="#" class ="btn btn-sm btn-primary">Hapus</a>
               </td> 
            </tr>
         <?php endforeach ?>
        </tbody>       
    </table>
   </div>
</div>
