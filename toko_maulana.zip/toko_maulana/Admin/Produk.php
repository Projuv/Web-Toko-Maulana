<div class="shadow p-3 mb-3 bg-purple rounded">
    <h5><b>Halaman Produk</b></h5>
</div>

<?php

$Produk = array();
$ambil = $Koneksi->query("SELECT * FROM Produk JOIN Kategori
 ON Produk.id_kategori = Kategori.id_kategori");
while($pecah = $ambil->fetch_assoc())
{
    $Produk[] = $pecah;
}

?>
<div class="card shadow bg-purple">
    <div class="card-body">
        <table class="table table-bordered table-hover table-striped" id="Tables">
            <thead>
                <tr>
                    <th>no</th>
                    <th>Kategori</th>
                    <th>Nama</th>
                    <th>Harga</th>
                    <th>Berat</th>
                    <th>Foto</th>
                    <th>Opsi</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($Produk as $Key => $value): ?>
                <tr>
                <td width="50"><?php echo $Key+1; ?></td>
                <td><?php echo $value['nama_Kategori']; ?></td>
                <td><?php echo $value['nama_Produk']; ?></td>
                <td>Rp<?php echo number_format($value['harga_Produk']); ?></td>
                <td><?php echo number_format($value['berat_Produk']); ?>Gr</td>
                <td><?php echo $value['foto_Produk']; ?></td>
                    <td classs="text-center" width="150">
                      <a href="#" class="btn btn-sm btn-primary">Edit</a>
                      <a href="#" class="btn btn-sm btn-danger">Hapus</a>    
                    </td>
                </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</div>