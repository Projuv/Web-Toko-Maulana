<div class="shadow p-3 mb-3 bg-purple rounded">
    <h5><b>Halaman Kategori</b></h5>
</div>

<?php

$Kategori = array();
$ambil = $Koneksi->query("SELECT * From kategori");
while($pecah = $ambil->fetch_assoc())
{
    $Kategori[] = $pecah;
} 

?>

<div class="card shadow bg-purple">
 <div class="card-body">
    <table class="table table-bordered table-hover table-striped" id="Tables">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Opsi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($Kategori as $Key => $value): ?>
            <tr>
                <td width="50"><?php echo $Key+1; ?></td>
                <td><?php echo $value['nama_Kategori']; ?></td>
                <td class="text-center" width=""150>
                    <a href="#" class ="btn btn-sm btn-primary">Edit</a>
                    <a href="#" class ="btn btn-sm btn-primary">Hapus</a>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
 </div>
</div>
