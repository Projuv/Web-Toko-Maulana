<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard</title>

  <!-- Bootstrap 4.6 CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
  
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">



  <style>
    .bg-purple {
      background-color:rgb(246, 248, 248); /* Warna ungu muda */
    }
  </style>
</head>
<body>

<div class="shadow p-3 mb-3 bg-purple rounded">
  <h5 class="bg-success text-white" style="padding: 10px; width: 1800px; font-weight: bold;">
    <marquee>Maulana Mahessar 50421800</marquee>
  </h5>

  <div id="carouselDashboard" class="carousel slide mb-4" data-ride="carousel">
    <div class="carousel-inner text-center">
      <div class="carousel-item active">
      <img src="/toko_maulana/Assets/img/1.jpg" class="d-block mx-auto" alt="Gambar 1" style="width: 800px; border-radius: 12px;">
      </div>
      <div class="carousel-item">
        <img src="/toko_maulana/Assets/img/3.jpg" class="d-block mx-auto" alt="Gambar 2" style="width: 800px; border-radius: 12px;">
      </div>
      <div class="carousel-item">
        <img src="/toko_maulana/Assets/img/2.jpg" class="d-block mx-auto" alt="Gambar 3" style="width: 800px; border-radius: 12px;">
      </div>
    </div>

    <!-- Carousel Controls -->
    <a class="carousel-control-prev" href="#carouselDashboard" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselDashboard" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>

  <a href="produksi.php" class="btn btn-outline-secondary">
    <i class="bi bi-arrow-clockwise"></i> rest
  </a>

  <table class="table table-striped mt-3">
    <!-- isi tabel -->
  </table>
</div>
  
<!-- Audio Element -->
<audio controls>
    <source src="/Toko_Maulana/Assets/Audio/Lagu Turu.mp3" type="audio/mpeg">
  </audio>
</div>

<!-- Video Element -->
<video width="800" controls style="display: block; margin: 20px auto; border-radius: 12px;">
    <source src="/Toko_Maulana/Assets/Video/Cinematic 30.mp4" type="video/mp4">
  </video>


<!-- jQuery, Popper.js, and Bootstrap JS for v4.6.0 -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js"></script>


</body>
</html>