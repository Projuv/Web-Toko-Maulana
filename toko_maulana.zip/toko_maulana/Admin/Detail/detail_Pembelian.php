<div class="shadow p-3 mb-3 bg-purple rounded">
    <h5><b>Halaman Detail Pembelian</b></h5>
</div>

<?php
$id_Pembelian = $_GET['id'];

$ambil = $Koneksi->query("SELECT * FROM Pembelian  JOIN pelanggan 
 ON pembelian.id_Pelanggan=pelanggan.id_Pelanggan 
 WHERE pembelian.id_Pembelian='$id_Pembelian'");
$detail = $ambil->fetch_assoc();
?>
<pre><?php print_r($detail); ?></pre>

<div class="row">

 <div class="col-md-4">
    <div class="card shadow bg-purple">
        <div class="card-header">
            <strong>Data Pelanggan</strong>
        </div>
        <div class="card-body row">
            <!-- -->
            <label class="col-md-4 col-form-label">Nama :</label>
            <label class="col-md-8 col-form-label"><?php echo $detail['nama_Pelanggan']; 
            ?></label>
            <!-- -->
            <label class="col-md-4 col-form-label">Email :</label>
            <label class="col-md-8 col-form-label"><?php echo $detail['email_Pelanggan']; 
            ?></label>
            <!-- -->
            <label class="col-md-4 col-form-label">Telepon :</label>
            <label class="col-md-8 col-form-label"><?php echo $detail['telepon_Pelanggan']; 
            ?></label>
            <!-- -->
        </div>
    </div>
 </div>

 <div class="col-md-4">
    <div class="card shadow bg-purple">
        <div class="card-header">
            <strong>Data Pembelian</strong>
        </div>
        <div class="card-body row">
              <!-- -->
              <label class="col-md-4 col-form-label">Tanggal :</label>
            <label class="col-md-8 col-form-label">
            <?php echo date("d F Y", strtotime($detail['tanggal_Pembelian'])); ?>
            </label>
             <!-- -->
             <label class="col-md-4 col-form-label">Total :</label>
            <label class="col-md-8 col-form-label">Rp<?php echo number_format($detail['total_Pembelian']); 
            ?></label>
            <!-- -->
            </div>
        </div>
    </div>

</div>

<?php 

$pp = array();
$ambil =$Koneksi->query("SELECT * FROM pembelian_Produk JOIN Produk 
ON pembelian_Produk.id_Produk=produk.id_Produk
Where pembelian_Produk.id_Pembelian='$id_Pembelian'");
while($pecah = $ambil->fetch_assoc())
{
    $pp[] = $pecah;
}
?>

<div class="card shadow bg-purple mt-3">
    <div class="card-body">
        <table class="table table-bordered  table-hover table-striped" id="Tables">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Harga</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($pp as $Key => $value): ?>          
            <?php $subtotal = $value['harga_Produk']*$value['jumlah']; ?>
            <tr>
                <td width="50"><?php echo $Key + 1; ?></td>
                <td><?php echo $value['nama_Produk']; ?></td>
                <td>Rp<?php echo number_format($value['harga_Produk']); ?></td>
                <td><?php echo $value['jumlah']; ?></td>
                <td>Rp<?php echo number_format($subtotal); ?></td>
            </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</div>