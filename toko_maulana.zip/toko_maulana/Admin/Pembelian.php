<div class="shadow p-3 mb-3 bg-purple rounded">
    <h5><b>Halaman Pembelian</b></h5>
</div>

<?php
$Pembelian = array();
$ambil = $Koneksi->query("SELECT * FROM Pembelian JOIN Pelanggan
ON Pembelian.id_pelanggan = Pelanggan.id_pelanggan");

while ($pecah = $ambil->fetch_assoc()) {
    $Pembelian[] = $pecah;
}
?>

<div class="card shadow bg-purple">
    <div class="card-body">
        <table class="table table-bordered table-hover table-striped" id="Tables">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Tanggal</th>
                    <th>Total</th>
                    <th>Opsi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($Pembelian as $Key => $value): ?>
                    <tr>
                        <td width="50"><?php echo $Key + 1; ?></td>
                        <td><?php echo htmlspecialchars($value['nama_Pelanggan']); ?></td>
                        <td><?php echo date("d F Y", strtotime($value['tanggal_Pembelian'])); ?></td>
                        <td>Rp<?php echo number_format($value['total_Pembelian']); ?></td>
                        <td class="text-center" width="150">
                            <a href="Index.php?Halaman=detail_Pembelian&id=<?php echo $value['id_Pembelian']; ?>"
                             class="btn btn-sm btn-info">Detail</a>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</div>
