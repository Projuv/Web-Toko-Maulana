<?php
$Koneksi = new mysqli("localhost","root","","toko_maulana");
?>